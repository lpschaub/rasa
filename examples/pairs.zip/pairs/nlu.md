## intent:DeliveryCost
- bonjour bonjour je passerai commande seulement si les [frais de port](fdp) sont à 0 € surtout pour une commande de 20 €. très cordialement. [Email1](email)
-   : bonjour,3    : [Email1](email) j'ai une commande à valider, pourrais avoir la livraison [offerte](free) ?
- J e vous ai précisé que je ne comprenais pas la différence de [facturation](biling) qui, [frais de transport](fdp) compris est de 97,94€ et au final on me réclame 100,96€. Merci. je m'a fait livrer à mon [domicile](place), je ne vois donc pas pourquoi sur le bon de commande les frais inclus sont arrêtés à un peu plus de 97€. j'ai commandé 2 articles. a vous lire. cordialement
- je pensais que les [frais de livraison](fdp) étaient [offerts](free) mais je ne trouve pas de [code](discount) pour cela
- bonjour j'ai choisi mes parfums prix 9,3 je fais étape suivante et la 1,3 alors que je n'ai pas encore choisi mon mode de livraison
- bonjour, les parfums sont expédiés des [USA](country) ?2   il peut y avoir des [frais](fdp) de douane ?
- bonjour vos [frais de port](fdp) sont [gratuits](free) à quel montant
- , est il possible de réduire le [coût de livraison](fdp) ?
- 7 a 10j c'est beaucoup pour 8€

## intent:Goodbye
- [dommage](mood_neg). Passez de bonnes fêtes de fin d'année.
- Merci de votre réponse bonne fin de journée à vous cdt
- Merci et bonne après midi
- Ok j'essaies merci  :  je dois appuyer ou sur la petite tête   : je n'y arrive pas je sors du chat et y reviendrai si besoin11    : Merci
- Merci pour vos informations bonne journée
- d'accord merci des renseignements bonne fin de journée
- et je ne peux revenir en arrière etc   : OK je vais [abandonner](cancel)
- d'accord merci au revoir
- merci bonne journée
- ok j'ai enregistre le suivi etc etc mais je reste [septique](mood_neg) pour le 2eme mail étant donne que le 1er mail y a pas eu de problème pour le réception et le suivi   : bonne journée
- pour votre réponse, bonne journée a vous.
- Merci j'attend le deuxième colis1   bonne journée
- [Super](mood_pos). Merci bonne journée
- au revoir
- Merci beaucoup de votre aide, je vous souhaite une bonne journée ! il y a )
- Merci mais lors de la commande la livraison était pour le [septembre](date) merci pour votre réponse je vais attendre bonne journée
- . Merci. bonne après midi
- Merci et à bientôt
- Merci en espérant recevoir mes produits très vite
- ah bon il faut des étoiles rouges ?3   je vais vérifier cela alors merci bonne journée
- merci   si rien [vendredi](date) je reviens vers vous
- : merci   : bonne journée
- oui j'ai eu mais il faut minimum 60 euros de commande  pas grave merci quand même bonne journée
- je vous remercie pour votre intervention [efficace](mood_pos) et je vous souhaite une bonne fin de journée
- ok merci bien à vous, bonne journée au plaisir.
- bye
- goodbye
- see you around
- see you later
- Merci beaucoup, bonne journée.
- ha oui je vais prodécer à une [commande](order), merci et bonne journée
- je vous remercie pour vos explications. je vais concrétiser la commande bonne journée
- Merci je n'avais pas de suivi. bonne journée. cordialement
- pas de soucis merci à vous bonne fin d'AP
- je verrai samedi matin. cordialement, Mr _Name4_.

## intent:PaymentRefused
- J problème pour régler2   : comment [régler](payment)
- City : bonjour  City : je ne possède ps d [portable](device), j'ai changé d'adresse après la vente de mon ancien appartement voulu par le propriétaire, demande de livraison en point relais notifié, mais impossible de régler ; j'annule tout ?
- City: oui, cela me marque numéro de [portable](device) non valide, je n'en ai jamais eu, et ce n'est pas ma première commande, sauf mon adresse perso qui changé, mais je préfère le point relais
- je suis déjà client et je n'arrive pas à payer
- bonjour, je voudrais payer mon achat de 1,9 Euros avec ma [carde](tool) américaine [MasterCard](tool), débit.2   : le [paiement](payment) a été refuse.3   : vous ne travaillez pas avec des [cartes américaine](tool) ?   : mail : [Email](email)   : IT s written : [payment](payment) could not be accepted
- bonjour   : je n'arrive pas à rentrer mon numéro de [carte bancaire](tool) etc. pourquoi. . Merci
- je ne peux pas aller en payment
- [Email1](email)   mon [paiement](payment) vient d'être refusé par votre site sur ma [carte mastercard](tool) des postes italiennes  j'ai bien reçus le code d'acceptation de mon débit par la [carte](tool)

## intent:PaymentTool
- il met, je veux régler avec [PayPal](tool) et moi non.je veux régler avec ma carte
- mauvaise expérience par [Paypal](tool)
- bonjour peut on [payer](payment) en plusieurs fois par [CB](tool) sur votre site svp

## intent:Thanks
- Merci, je vais aller rectifier tout cela !
- Merci
- ok merci
- ah ok merci
- Merci à vous et désolée mais j'ai eu du mal à me rappeler comme il fallait faire pour échanger toutes les deux.  je l'essaie et si problème je reviens vers vous. cela a semble t il marché.  un grand merci à nouveau.
- ok mmerci
- je vais essayer et si cela ne fonctionne pas, tant pis, j'annule. Merci
- ok merci bien
- merci
- j'essaie  merci
- Merci beaucoup, en m'excusant.
- ok d'accord je vais attendre  je vous remercie
- d'accord   merci beaucoup
- très bien, merci je vais commander sur un autre site,
- oui j'entend j'espère juste la recevoir   Merci
- Ok merci je préfère une livraison expresse a [domicile](place)   je valide mon achat
- oui merci
- d'accord, je attend un peu,   merci pour votre aide
- alors aujourd'hui je comprends. doc je dois patienter. Merci
- tétard : OK je le note et vous rappelle si je n'i rien le 15 Merci
- merci, j'attends votre retour
- DAC
- merci terminé
- je le fais tout de suite   Merci
- ah ok
- très bien merci
- merci beaucoup je vais essayer
- Merci
- je vais essayer, je reprends contact au cas où. Merci
- Merci beaucoup pour votre aide
- ok merci
- OK Merci.
- merci beaucoup
- ok merci
- d'accord merci car je pensais qu'il avait pu être volé dans ma boite aux lettres
- ok je vais essayer c'est BON j'avais écrit le [mot de passe](pwd) EN minuscule Merci beaucoup
- OK je vous remercie
- Merci
- Merci pour cette réponse

## intent:Previous
- la réponse à ma question précédente ? ! !
- répondez vous vraiment aux [e-mails](channel) ?
- j'ai choisi en [point relais](pr)
- la réponse à ma question précédente ? ! !
- répondez vous vraiment aux [e-mails](channel) ?

## intent:Autre
- bonjour2   : quelqu'un est il la pour répondre ?
- je ne trouve nulle part mon numéro de commande
- le [renvoie](resend)
- in , please ?2  I have an order : NR : 0201 7041 4639 69773  I do not know Where the order has been delivered ?4  are you taire ?
- je suis en [France](country) normalement.
- _Name2_ je fais autrement

## intent:ProductAvailable
- avez vous des [recharges](reload) pour le [Chanel](article) ? 
- bonjour, client chez vous je souhaite faire plaisir à mon [amie](target) pour lui offrir [womanity EAU de parfum spray](article), j'aimerai savoir si ce produit sera toujours [rechargeable](reload), merci de votre réponse, mon mail [Email1](email). cdt
- bonjour je voudrais savoir si l'[eau de toilette](article) en [2ml](size) pour un [homme](target) de chez  a un emballage [cadeau](present) et combien de temps de livraison a [domicile](place) avec les [frais de port](fdp)
- Merci vous de même a propos avez vous la gamme à savoir [Doorella](article) ou [Diorissimo](article)
- bonjour,  je souhaiterais savoir si vous avez encore le [Courrèges in blue](article) s'il vous plaît.
- bonjour je voudrais vous commander pour ma [mère](target) le [N°5](article) eau de parfum de [channel](article) mais je ne le vois pas, merci de m'aider à le retrouver.
- bonjour je cherche [parure de Gerlain](article) pouvez vous me le trouver c'est un ancien parfum
- vous allez, es chercher à travers le monde etc suite à quoi, liquidations ou autres. avez vous la [petite robe black](article)
- quels sont vos parfums [Ted Lapidus](article) ?
- bonjour, j'ai entendu de votre parfum [Bvlgari](article) maman petit et je veux commander mais le problème je ne connais pas vraiment, est ce qu'il y a un moyen d'avoi des [échantillons](sample) ? merci
- bonjour je veux connaître la disponibilité du [coffret cadeau homme idéal](article) [100ml](size) a 69,99, est le vrai parfum ?
- est ce que vous avait le parfum [Repetto](article) le dernier

## intent:DamagedPackage
- bonjour3   : hier nous avons reçu une commande ou un produit était [casse](damaged) et nous vous avons transmis un document de [Chronopost](transporter) attestant ce problème
- le [renvoi](resend) et si possible nous l'envoyer [chez nous](place)
- bonjour,   c'est la troisième fois que je commande mon parfum [Insolence](article) de chez vous. j'ai été très [satisfaite](fdp) les deux premières fois mais j'ai reçu hier ma troisième commande et quelle déception : il s'agit de l'ancien conditionnement et l'eau de parfum a viré : cela ne sent pas du tout comme d'habitude. je suis très [déçue](mood_neg). pouvez vous faire quelque chose ? cela m'ennuie de [renoncer](cancel) à commander chez vous   mon adresse mail est : [Email1](email)
- : [Email1](email)   commande [00](order) crèmes onctueuses [lolitalempica](article) [abîmées](damaged)
- je viens de recevoir mon eau de parfum [Angel](article) que je mets depuis très longtemps. j'ai ouvert le paquet et vu la bouteille, déjà la couleur est bleu gris et l'odeur est différente de celle que j'ai encore en ma possession.   voici mon email : [Email1](email)
- bonjour suite à ma dernière commande j'avais fait part par mail de mon [mécontentement](mood_neg). j'ai envoyé une [photo](photo) du parfum dont la couleur me semble [anormale](damaged) sans parler de l'odeur qui semble passée. à ce jour je n'ai aucunes nouvelles

## intent:Rien
- ok l'adresse est bonne tel mob Phone2
- [Email1](email)
- [email@email.com](email)
- [Email@ntin.fr](email)
- [email@emaiil.fr](email)
- [mon@adress.fr](email)
- colis X - commande du [15/09/18](date) N° [00](order)
- oui mon N de commande est [4565](order)
- [e@mel.fr](email)
- [Email1](email)   CwmFYCaC
- [54678](order)
- [mon@mel.fr](email)
- je suis Melle mon adresse 75 avenue du docteur résidence City3 ZipCode1 City2 [Email1](email)  mon [mot](pwd) de [passe](pwd) [Email2](email)
- [4968](order)
- [_Email1_](email)
- [Soldes10](code)
- _Name2_ [_Email1_](email) [679295](order)  [01/11/1967](date) [31 rue _City2_ _ZipCode1_ _City1_](address)
- [_Email2_](email)
- [716283](order) [716664](order) pareil
- alors que j'ai commandé il y a peu de temps  [_Email1_](email)
- [xu073787671r](order) et [XU073810295FR](order)
- _Name3_ mon [panier](basket)
- [699072](order)
- [femme](target)
- [465897](order)

## intent:Discount
-   : d'accord, un [code promo](discount) peut être ?
- bonjour puis je avoir un [code promo](discount) pour mon [anniversaire](event) ?
- bonjour je souhaite commander aujourd'hui un [parfum](article) est ce que j'aurai ne [réduction](discount) en plus ? si oui quel code, merci
- j'ai mis le code [MDM0](code) pour une [remise](discount) et l'on me répond code expire quand un nouveau [code remise](discount) sinon je diffère ma commande
- Name : Ca passe le code de [NOEL](code) ou [NOEL02](code)   Ca. passe pas
- c'est ça j'ai fait mai Ca passe ps la [réduction](discount)
- ni un petit geste commercial  qui pourrait correspondre
- c'est mon [anniv](event) la semaine prochaine, aurais je le droit à une [réduc](discount) ? 
- bonjour, je souhaite acheter 4 flacons de parfum mais je trouve le tarif de livraison très cher etc ! feriez vous vous un geste commercial ? Merci
- bonjour je suis une fidèle cliente et j'aimerais commander du parfum mais encore 7.90 de [frais](fdp) de [port](fdp) ne pourrais je pas avoir les parfums sans [frais](fdp) de [port](fdp) merci
- bonjour  c'est ma première commande, 148 euros, je ne veux pas payer les [frais](fdp) de [port](fdp), avez vous un [code](discount) d'ebienvenue ?4  s'il vous plaît, merci
- ah d'Accord. pas d'autre [promotion](discount) en vue ?
- je ne peux bénéficier du [bon](discount) de 5 € ni de 10 €
- et le [code](discount) [_Name2_](code) est il encore valable ?
- où est mon [code de réduction](discount) ?
- [_Email1_](email)  juste avoir le [code promo](discount) pourcent
- bonjour bonjour le [code promotionnel](discount) ne fonctionne plus ? Merci
- bonjour, étant bon client, je souhaiterais avoir un [code promo](discount) avant de passer commande c'est possible ? Merci.
- je souhaite bénéficier un [code promo](discount)
- bonjour, le site annonce qu'il existe un [code promo](discount) - je ne le trouve pas
- Merci de bien vouloir m'envoyer les [codes de réductions](discount) par [mail](channel).

## intent:DeliveryNews
- bonjour je voudrais savoir si ma commande [483265](order) était bien arrivée svp
- bonjour je voudrais savoir où se trouve ma commande [361](order)
- pouvez vous me dire où en est ma commande passée le [16/11/2018](date)
- bonjour quand va arriver ma commande commande [40564](order) Merci
- bonjour je voudrai offrir le parfum que j'ai commandé [dimanche 2](date) et je ne l'ai toujours pas reçu est ce que je l'Arai à temps ?2   : [Email1](email)
- bonjour, j'ai effectué une commande mais je n'ai toujours rien reçu alors que c'et par [Chronopost](transporter)
- bonjour. a ce jour je n'ai pas reçu ma commande
- bonjour numéro [4512](order) [Email](email) je voulais savoir quand je reçois mon parfum
- bonjour, je n'ai pas reçu ma commande N # [00](order) pour [Email1](email), passé le [10/06/19](date) Mercie de votre réponse.
- bonjour   ma commande N [00](order) apparaît toujours en dépôt chez l'expéditeur alors qu'il était indiqué que la livraison était prévue pour [samedi](date) en [point relais](pr). est ce normal ? je m'inquiète un peu
- [00](order)   ma commande est notée toujours en cours de livraison ? .
- pourriez vous me dire si ma commande [00](order) est partie. Merci
- City1 : j'ai commandé un parfum pouvez vous me dire où en est ma commande [Email1](email)  City1 : ma commande porte le N [00](order)
- 00 numéro de commande
- bonjour j'ai passé une commande numéro [00](order) le [22/09](date) on est le 27 toujours rien reçu et c'est pour un. anniversaire [samedi](date) etc etc où en est la livraison car aucune info de votre part  merci
- CDE [00](order) le premier [envoi](resend) a échoué problème
- bonjour,   [Email1](email) - bonjour, je n'ai pas reçu ma commande encore.
- je veux savoir 0'en est ma commande dièse [00](order)
- [Email1](email)   commande 00   bonjour quel est le délai de livraison car j'ai commandé le [09/04/19](date) et toujours pas reçu etc   avec des [frais](fdp) de livraison à 14 € etc je m'attendais à une livraison bien plus rapide !
- commande n° [00](order) bonjour.cela fait 10 jour que ma commande a été expédié. elle n'est toujours pas en [france](country)
- nous étions en conversation à propos de ma commande mon colis est annoncé chez [chrono](transporter) post comme " " prêt chez l'expéditeur " " mais toujours rien reçu
- bonjour ?3  je souhaite avoir plus d'informations à propos de la commande numéro [10](order) ; en effet, elle est en attente d'envoi depuis 5 jours, je voulais savoir si vous aviez des informations ! merci à vous il y a )
- bonjour j'ai fait une commande le [26 août](date) et je suis sans nouvelle ma commande est numéro [00](order) merci de m'aider cordialement
- bonjour  vernat : je voudrais savoir où en est ma commande
- bonjour,   bonjour   je voudrais savoir où en est ma livraison en cours depuis le [14 octobre](date). Commande [00](order)
- bonjour je n'ai pas de nouvelle de ma commande   il s'agit de la commande numéro [00](order)
- [Email1](email)  commande [03](order)  a quand la livraison ?
- numéros commandés [02](order) et [00](order) du 27 [mars](date) aucune nouvelle
- je souhaite savoir où en est ma commande [00](order) du [1 juin 2019](date)   [Email1](email)
- : bonjour   : pouvez vous me dire où en est ma commande [00](order)?  : adresse mail : [Email1](email)
- bonjour pouvez vous m'indiquer la date prévue de livraison de ma commande N : [00](order) merci
- bonjour, je reviens vers vous concernant le colis que je n'ai jamais réceptionné.
- pouvez vous me dire où en est ma commande passée le [16/11/2018](date)
- bonjour où en est ma. commande svp
- bonjour commande [719512](order) pouvez vous me donner une date de livraison car prévu samedi [1er juin](date)
- je voudrais savoir où en est ma commande ?
- bonjour pourriez vous me dire où en est ma commande j'ai effacé le [mail](channel) merci [_Email1_](email)
- bonjour j'attends ma commande du [16 juin](date) toujours en attente chez l'expéditeur. le délai est très long. [commande 608380](order)
- bonjour Madame ma [commande 605565](date) sur chronoposte est toujours en préparation depuis le [24/05](date) etc et je parts à l'étranger le [31/05](order) Mercie de me renseigner
- bonjour, la livraison sera pour avant Noel ? cordialement.
- bonjour email _Email1_ je n'ai toujours pas reçu ma [commande](order) du [20](order) mars est ce normal ?
- bonjour, numéro de [commande 604337](order) j'aimerais savoir ou est le colis aucun détail depuis le [31 mai](date)
- bonjour j'aimerais savoir où en est l'expédition de ma [commande](order).
- bonjour il y a t il un recours en cas de non [livraison](delivery), un [e-mail](channel) ou un [téléphone](channel) où vous appelé si nous avons un problème
- je me suis fait avoir en commandant ailleurs, pouvez vous me confirmer le délai d'[acheminement](order) pour une commande que je serai susceptible de vous faire et quel recours j'ai en xcas de non [livraison](delivery)
- [716640](order) bonjour cette commande est en cours de [livraison](delivery) depuis le [15 mai](order) dernier. pourrais je avoir de plus amples informations
- bonsoir, pouvez me dire si ma commande a été expédiée [649843](order)
- bonjour, bonjour, j'ai passé une commande le 26 juin numéro [726648](order) et ça fait [2 semaines](date) que c'est en cours de [livraison](delivery), je la reçois qaund car je pars bientôt en vacances, merci
- bonjour je vous contact au sujet de ma commande que je n'ai toujours pas eu

## intent:WebsiteBug
- bonjour [Email1](email) mon panier est de 60,18 hors en poursuivant je dois 62,18 parfum insolence [Guerlain](article) - code promo +7,99 [frais de port](fdp) 60,182   : [Email2](email)   :  [Email1](email) je suis mal voyante4   : hier même problème donc pas commandé5   : maintenant le total TTC est monté à 64,88 ?
- je sais mais ça ne passe pas  je connais bien le fonctionnement : j'ai travaillé dans ce secteur. apparemment votre site [dysfonctionnait](bug) quand j'ai voulu saisir.8  je réessaierai plus tard
- :  rebonjour je ne peux pas [téléchargé](action) les commandes de votre site
- il ne sont pas affiché
- mais je ne sais pas vider les caches ?
- quand je suis sur le total de mes achats il est maequé étape suivante et il ne veux pas le prendre
- je l'ai fait mais ça [bloque](bug) !
- je viens de créer mon compte. j'ai tout rempli on me demande un nom de [transporteur](transporter) que je ne trouve pas etc
- Ca me dit échec lors de [l'authentification](authentification)
- c'est fait mais rien de changé !
- problème de connection en cours [_Email1_](email)

## intent:CommuncationInterruption
- je vais le faire si je sors de la conversation cela coupera t il notre entretien
- bonjour, j'ai déjà eu une conversation avec vous et je viens d'être coupée  avec ;2   pouvez vous relancer [Chronopost](transporter) puisque le colis est arrivé chez eux le 1er octobre et nous sommes le 10 octobre.
- je vais le faire si je sors de la conversation cela coupera t il notre entretien
- bonjour, j'ai déjà eu une conversation avec vous et je viens d'être coupée  avec ;2   pouvez vous relancer [Chronopost](transporter) puisque le colis est arrivé chez eux le 1er octobre et nous sommes le 10 octobre.

## intent:PurchaseIssue
- bonjour je n'arrive pas à passer ma commande  [Email](email)
- bonjour, je ne parviens pas à passer ma commande
- bonjour, vous demandez d'indiquer un [transporteur](transporter), je ne comprends pas
- je n'arrive pas à commander
- bonjour, je souhaite une livraison à [domicile](home) mais je n'arrive pas à trouver ?

## intent:Login
- bonjour Madame2  ayant oublié mon [numéro de passe](pwd), il m'a été proposé différents nouveaux n° mais aucun ne me permet de finaliser ma commande. comment faire ? Merci.
- c'est .2  j'essaie de passer commande de 2  mais impossible de se [connecter](connection) via [FB](facebook). j'ai saisi également le formulaire qui est rejeté pour [mot de passe](pwd)
- bien que j'aie cliqué sur [mot](pwd) de [passe](pwd) oublié on ne me [renvoie](resend) pas de [mail](channel) de renouvellement
- j'ai reçu un nouveau [mot](pwd) de [passe](pwd) je n'arrive pas à passer commande
- échec d'[authentification](bug)  vous êtes là
- c'est noté, il y a 1 erreur, 1 échec lors se l'[authentification](bug)
- bonjour 2  hier j'ai appelé un conseiller cela a duré longtemps pour créer mon compte et malheureusement impossible de me [connecter](connection) motif il y a une erreur dans l'[authentification](bug) il y a pouvez vous M, aider et vérifier merci
- j'arrive pas à me co via [facebook](facebook)
- je n'arrive pas à commander car a priori mon [adresse mail](channel) est [incorrecte](wrong)
- bonjour, je ne me souviens plus du [mot de passe](pwd) pour accéder à mon compte, cela fait 2 fois que je le demande et je n'ai encore pas de réponse, pouvez intervenir, merci
- bonjour besoin d'un [mot de passe](pwd) pour valider ma commande
- je n'arrive pas à commander car a priori mon [adresse mail](channel) est [incorrecte](wrong)
- EN fait, je reprends toujours le [mot de passe](pwd) que vous me donnez etc etc comment modifier ce [mot de passe](fdp) ?
- et je suis sur mon compte etc etc etc l'adresse qui est indiquée dans les commands précédentes est celle de _City1_ dans le Nord etc etc mais nous sommes dans le Var maintenant. je le vois parce que je suis sur LA rubrique : MES commandes, mais si je vais sur la rubrique " " MES adresses " " je n'ai rien du tout et ne peux rien changer on me le refuse et donc, si je vais sur " " mes informations " " je retrouve le nom, le prénom, l'adresse mail, la date de naissance et oui effectivement on me demande un nouveau [mot de passe](pwd) mais lequel ? je vais devenir chèvre avec cette commande ?
- celui donne par vos collègues _Name2_
- pour les prochaines commandes dois je toujours me servir du même [mot de passe](pwd) ?

## intent:DeliveryNews+AskDetails
- Name : est ce normal qui le est toujours pas parti de [chez vous](store)
- oui mais depuis lundi c'est comme ça  commande n'évolue pas etc  c'est normal ?
- bonjour,  j'ai commandé un parfum la semaine dernière, commande n° [5640](order). je ne l'ai toujours pas reçu. j'ai appeler [Chronopost](transporter) qui m'a indiquer que le colis est toujours [chez vous](store)   : qu'en est il ?
- oui toujours en dépôt alors ?
- depuis le [24 mai](date) le colis est toujours en préparation ! ! ! ! ! l'avancement n'est pas mentionné. quand vais je le recevoir.
- ma commande tarde à arriver ! ça fait 6 jours, et c'est du [Chronopost](transporter), donnez moi des nouvelle svp
- tétard : donc depuis le [31/12](date) ça suppose que je le reçoive entre le aujourd'hui et [samedi](date) ? si je n'ai rien [samedi](date) qu'est ce que je fais ?
- voilà mon adresse mail [Email1](email)   j'ai passé une commande [samedi](date) et dans le [suivi](follow-up) du colis je ne vois pas où il est
- bonjour, j'ai fait une commande sur votre site et je suis [inquiète](mood_neg) car je n'ai pas de numéro de [suivi](follow-up)   le colis n'est toujours pas parti ?
- lorsque je vais vers le [transporteur](fdp) avec mon numéro de colis il me dit qu'il n'a pas d'information à propos de ce numéro de

## intent:AskDetails
- portant sur le lien il dise qui le est toujours [chez vous](store)
- [Email](email)  vous voudrez bien me tenir informée svp, je vais devoir décrocher. Merci beaucoup
- j'ai regardé il m'informe en cours de traitement
- merci mais il est quand même dans une boite cartonnée
- bien expliquez moi le calcul
- et ?
- quand ? heure et date svp
- donc ?3  je livrée avant [Noel](date)
- pardon ?
- ça vient d'où ? les livreurs viennent à pied ?
- une idée du délai ?
- pourquoi
- _Name3_ etc donc je dois attendre de recevoir le [mail](channel) pour le parfum [manquant](missing) etc c'est ça ? Merci
- c'est quoi [navigateur](website) ?
- ok, mais vous ne mettez rien a jour ? si le colis a été expédié le [31](date) ou est il ?
- ok est ce que je peut le voir

## intent:MissingItem
- bonjour, j'ai reçu une commande mais il me manque un produit à l'intérieur, vais je le recevoir ? Merci
- où en est ma commande je n'ai eu que 3 produits sur 4 commande du [1juillet](date) on est le 3
- Commande [00](order)  bonjour je n'ai reçu que un colis sur les deux est ce normal ? Merci
- bonjour   j'ai passé une commande de parfum mais je n'ai pas reçu la totalité de ma commande
- où en est le reste de ma commande N [00](order)
- bonjour _Name1_, lors de ma dernière commande du [29/06](date) dernier j'avais commandé 2 articles, un m'a été [remboursé](refund) car plus disponible et l'autre n'a toujours pas été livré, lorsque je regarde mes commandes sur votre site, état dit : [en cours](status) de livraison, l'article restant va t il être livré ou pas ? vais je être remboursée ou pas ?
- bonjour je n'ai reçu que 2 parfums sur 3 commandes etc pouvez vous me dire quand je recevrai [Gucci by Gucci](article) etc merci etc car mon compte a été [débité ](payment) des 3 etc etc cordialement

## intent:ReceptionAlert
- merci. je vais recevoir un [sms](channel) pour me dire de venir la retirer ?
- pourriez vous me communiquer sur mon [portable](channel) dès que le colis arrive dans le [point relais](pr) ?4   voici mon N [Phone1](phone). Merci
- je vois rien
- serai je prévenue de la date de livraison ? tel : [phone2](phone)
- bonjour,   serais je informée par [sms](channel) de la livraison de ma commande dans le [point relais](pr) ?
- d'accord. je reçois un [mail](channel) pour pouvoir le réceptionner ?
- merci. je vais recevoir un [sms](channel) pour me dire de venir la retirer ?
- pourriez vous me communiquer sur mon [portable](channel) dès que le colis arrive dans le [point relais](pr) ?4   voici mon N [Phone1](phone). Merci
- je vois rien
- serai je prévenue de la date de livraison ? tel : [phone2](phone)
- bonjour,   serais je informée par [sms](channel) de la livraison de ma commande dans le [point relais](pr) ?
- d'accord. je reçois un [mail](channel) pour pouvoir le réceptionner ?

## intent:CustomerComplaint
- oui mais j'ai reçu un mail avec 6 % de réduction pour  [publicité](add) mensongère, ?
- mais je n'ai pas eu de [mail](channel) pour me prévenir que ma commande était en 2 colis je l'ai su par le [relais](pr) et pas eu de message pour me faire part de délai  etc 2 jours pour la livraison ce n'est pas ce que vous proposez lors des commandes et des [frais](fdp) de [port](fdp) proposes c'est a réfléchir par deux fois avant de repasser commande chez vous désolée mais je reprendrai nocive ou Sephora
- depuis votre intervention aucune nouvelle de [Chronopost](transporter) et vous pensez que demain il y en aura une ? la dernière fois que vous m'avez proposé de reprendre contact le lendemain, le système conversation ne fonctionnait pas. j'ai donc appelé le service client à 40 centimes la minute etc etc etc ! ! ! ! je suis [furieuse](mood_neg)
- le remboursement ne me convient pas. il s'agissait d'un [cadeau](present) donc je persiste à dire qu'il s'agit probablement d'un vol chez [Chronopost](transporter) donc à eux de régler le problème
- : x mails appels depuis5 jours aucune réponse   : la photo ne vous donnera pas l'odeur 
- votre [pub](add) annonçait des [frais de port](fdp) offerts !! c'est n'importe quoi
- oui mais j'ai reçu un mail avec 6 % de réduction pour  [publicité](add) mensongère, ?
- mais je n'ai pas eu de [mail](channel) pour me prévenir que ma commande était en 2 colis je l'ai su par le [relais](pr) et pas eu de message pour me faire part de délai  etc 2 jours pour la livraison ce n'est pas ce que vous proposez lors des commandes et des [frais](fdp) de [port](fdp) proposes c'est a réfléchir par deux fois avant de repasser commande chez vous désolée mais je reprendrai nocive ou Sephora
- depuis votre intervention aucune nouvelle de [Chronopost](transporter) et vous pensez que demain il y en aura une ? la dernière fois que vous m'avez proposé de reprendre contact le lendemain, le système conversation ne fonctionnait pas. j'ai donc appelé le service client à 40 centimes la minute etc etc etc ! ! ! ! je suis [furieuse](mood_neg)
- le remboursement ne me convient pas. il s'agissait d'un [cadeau](present) donc je persiste à dire qu'il s'agit probablement d'un vol chez [Chronopost](transporter) donc à eux de régler le problème
- : x mails appels depuis5 jours aucune réponse   : la photo ne vous donnera pas l'odeur 
- votre [pub](add) annonçait des [frais de port](fdp) offerts !! c'est n'importe quoi

## intent:CancelOrder
- bonjour, je viens de passer à l'instant ma commande qui a pour numéro [4056](order)   : seulement je viens de me rendre compte que je me suis trompée etc. y a t il possibilité d'annuler celle ci etc ?
- je veux annuler ma commande [00](order)
- Bonjour je voudrais que vous annuliez ma commande svp
- bonjour, je viens de passer à l'instant ma commande qui a pour numéro [4056](order)   : seulement je viens de me rendre compte que je me suis trompée etc. y a t il possibilité d'annuler celle ci etc ?
- je veux annuler ma commande [00](order)
- Bonjour je voudrais que vous annuliez ma commande svp
- _Name3_ je modifier ma [commande](order) puisque non partie ?

## intent:AccountIssue
- : dans mon compte les fichiers pdf je ne peux pas les télécharger    : commande No [0897](order) et les anciennes commandes    : je ne comprends pas car sur les autres sites je peux [télécharger](action) mes [factures](biling) relatives aux commandes    : dans mon compte    : comment puis je faire ?
- : dans mon compte les fichiers pdf je ne peux pas les télécharger    : commande No [0897](order) et les anciennes commandes    : je ne comprends pas car sur les autres sites je peux [télécharger](action) mes [factures](biling) relatives aux commandes    : dans mon compte    : comment puis je faire ?
- _Email1_ suis en train désespérément de vous passer une [commande](order). quant le panier est OK et que je passe à l'étape suivante etc etc on me dit vos adresses Fact et exp sont ci-dessous etc etc et rien n'apparaît ? et si je veux ajouter une adresse etc etc ça me répond " " 1 _Name1_ " ". je ne peux donc passer à l'étape paiement et suis [bloquée](bug)
- bonjour je n'arrive pas à [valider](action) ma commande malgré le nouveau [mot de passe](pwd) mon adresse [mail](channel) est [_Email1_](email)
- je ne peut pas finalise ma commande

## intent:ProductTarget
- bonjour, une question sur le [fond de teint make up for ever fluide](article) tenseur le coloris sable est il bien clair merci
- c'est quoi que vous me conseillez pour une [ado](target) ? 
- j'aurais besoin d'une eau de toilette  pour [femme](target) d'un certain âge 
- je voudrais faire un cadeau à mon [fils](target), une idée ? 
- bonjour, une question sur le [fond de teint make up for ever fluide](article) tenseur le coloris sable est il bien clair merci
- c'est quoi que vous me conseillez pour une [ado](target) ? 
- j'aurais besoin d'une eau de toilette  pour [femme](target) d'un certain âge 
- je voudrais faire un cadeau à mon [fils](target), une idée ? 
- que me conseillez vous en parfum [femme](target) pour ma [mère](target) ( 75 ans ) merci.
- bonjour je recherche une [eau de toilette](article) pour une [pré-ado](target) de 10 ans

## intent:DeliveryTime
- [super](mood_pos).6  pensez vous que je serai livrée la semaine prochaine ? je vis en Martinique et viens en métropole ce samedi pour une semaine. je demande la livraison chez mon fils à City
- j'espère le recevoir ace Xe week-end le [cadeau](present) de la fête des pères
- oui je voulais commander un parfum combien du temps pour être livrer car le part en vaconce à la fin du mois
- je désire passer commande. je serais livrer avant Noël ?
- bonjour   je voudrais savoir LE TEMPS de livraison pour une commande
- [super](mood_pos).6  pensez vous que je serai livrée la semaine prochaine ? je vis en Martinique et viens en métropole ce samedi pour une semaine. je demande la livraison chez mon fils à City
- j'espère le recevoir ace Xe week-end le [cadeau](present) de la fête des pères
- oui je voulais commander un parfum combien du temps pour être livrer car le part en vaconce à la fin du mois
- je désire passer commande. je serais livrer avant Noël ?
- bonjour   je voudrais savoir LE TEMPS de livraison pour une commande

## intent:ConfirmationOrder
- pourquoi je n'ai pas eu de message pour me prévenir des références du 2eme colis avec un numéro de [suivi](follow-up)
- ok je regarde   : [dommage](mood_neg) que les + vieux messages des [indésirables](spam) soient du [2 juillet](date) mais dans la liste des [indésirables](spam) il n'y a pas aucun de votre site etc ce qu'il serait bien est que vous me l'envoyez de nouveau ce mail etc merci
- [Email2](email)  je voulais savoir si ma commande a biens été pris en compte car j'ai été débité 2 fois de 244.94 car j'ai appelé ma banque  [Email1](email)
- bonjour, j'ai passé une commande hier, que j'ai réglée par [carte bancaire](tool), j'ai fait une capture d'écran du [paiement](payment), mais sur mon compte il apparaît que je n'ai pas de commande en cours, d'autre part je n'ai pas reçu [confirmation](confirmation) de ma commande
- alirs faites la livraison en [point relais](pr)  merci de le [confirmer](confirmation)
- pourquoi je n'ai pas eu de message pour me prévenir des références du 2eme colis avec un numéro de [suivi](follow-up)
- ok je regarde   : [dommage](mood_neg) que les + vieux messages des [indésirables](spam) soient du [2 juillet](date) mais dans la liste des [indésirables](spam) il n'y a pas aucun de votre site etc ce qu'il serait bien est que vous me l'envoyez de nouveau ce mail etc merci
- [Email2](email)  je voulais savoir si ma commande a biens été pris en compte car j'ai été débité 2 fois de 244.94 car j'ai appelé ma banque  [Email1](email)
- bonjour, j'ai passé une commande hier, que j'ai réglée par [carte bancaire](tool), j'ai fait une capture d'écran du [paiement](payment), mais sur mon compte il apparaît que je n'ai pas de commande en cours, d'autre part je n'ai pas reçu [confirmation](confirmation) de ma commande
- alirs faites la livraison en [point relais](pr)  merci de le [confirmer](confirmation)
- commande N° [653320](order) bonjour etc es ce normal suite à une commande passée hier soir que je n'ai pas reçu un [mail](channel) de confirmation de commande alors que j'ai pu avoir la facture accessible sur le compte créé ?

## intent:DeliveryNews+CustomerComplaint
- vous voulez dire 2e [envoi](action) car depuis le [26 Mars](date) il y a UN gros SOUCI
- vous êtes Sure que je serai livré cette année ! cela fait 3 fois que l'on me donne de nouveaux délais
- bon ! vous comptez me livrer quand ?? ca fait 3 semaines que j'attends !!
- vous voulez dire 2e [envoi](action) car depuis le [26 Mars](date) il y a UN gros SOUCI
- vous êtes Sure que je serai livré cette année ! cela fait 3 fois que l'on me donne de nouveaux délais
- bon ! vous comptez me livrer quand ?? ca fait 3 semaines que j'attends !!

## intent:CustomerComplaint+goodbye
- si en fin de semaine je ne V oi rien vous voudrez bien procéder au [remboursement](refund) de mon article sous les meilleurs délais
- c'est très long pour le prix etc merci au revoir   PS : je ne suis pas sûre du tout de recommander un jour
- je n'ai reçu aucun message pour me prévenir etc etc   merci du renseignement et bonne journée à vous
- j'ai dû faire appel à l'avocat de notre entreprise pour pouvoir faire avancer ce dossier. en parallèle j'ai été obligé d'aller acheter les parfums en boutique ( qui m'a finalement coûté le même prix que chez vous grâce aux remises clients ). de cette manière, je vous demanderai un [remboursement](refund) sans plus tarder comme il l'est prévu par la loi [Française](country). aussi, si vous refuser sous prétexte de procédures [Chronopost](transporter), sachez que nous sommes aussi en contrat avec [Chronopost](transporter) et que notre chargé d'affaire m'a fait savoir que la procédure était singulière et que c'était à la boutique de faire immédiatement le nécessaire pour répondre aux exigences de la loi. sans [remboursement](refund) de votre part, je serai contraint de faire une plainte contre votre entreprise pour non respect de la législation [Française](fdp) dans la cadre d'un colis jamais réceptionné, et demanderai la [remboursement](refund) via le [fond](article) d'aide aux victimes.
- si en fin de semaine je ne V oi rien vous voudrez bien procéder au [remboursement](refund) de mon article sous les meilleurs délais
- c'est très long pour le prix etc merci au revoir   PS : je ne suis pas sûre du tout de recommander un jour
- je n'ai reçu aucun message pour me prévenir etc etc   merci du renseignement et bonne journée à vous
- j'ai dû faire appel à l'avocat de notre entreprise pour pouvoir faire avancer ce dossier. en parallèle j'ai été obligé d'aller acheter les parfums en boutique ( qui m'a finalement coûté le même prix que chez vous grâce aux remises clients ). de cette manière, je vous demanderai un [remboursement](refund) sans plus tarder comme il l'est prévu par la loi [Française](country). aussi, si vous refuser sous prétexte de procédures [Chronopost](transporter), sachez que nous sommes aussi en contrat avec [Chronopost](transporter) et que notre chargé d'affaire m'a fait savoir que la procédure était singulière et que c'était à la boutique de faire immédiatement le nécessaire pour répondre aux exigences de la loi. sans [remboursement](refund) de votre part, je serai contraint de faire une plainte contre votre entreprise pour non respect de la législation [Française](fdp) dans la cadre d'un colis jamais réceptionné, et demanderai la [remboursement](refund) via le [fond](article) d'aide aux victimes.

## intent:Non
- eu h non je suis sur mon lieu de travail   pourtant ça a été prélevé le [7/06](date)
- ah non 12 14 jours
- non
- je pense pas que ce soit le problème
- eu h non je suis sur mon lieu de travail   pourtant ça a été prélevé le [7/06](date)
- ah non 12 14 jours
- non
- je pense pas que ce soit le problème
- no
- never
- I don't think so
- don't like that
- no way
- not really
- non merci
- se n'ai pas lui [dommage](mood_neg)

## intent:ChangeData
- peut on changer le [mot](pwd) de [passe](pwd) que j'ai marqué
- Je voudrais modifier mon adresse svp 
- comment on édite ses données ? 
- par contre l'adresse n'est plus la même, je n'habite plus à _City1_
- peut on changer le [mot](pwd) de [passe](pwd) que j'ai marqué
- Je voudrais modifier mon adresse svp 
- comment on édite ses données ? 
- par contre l'adresse n'est plus la même, je n'habite plus à _City1_
- pouvez vous changer l'adresse de facturation pour ma commande n° [625652](order). mettre la même adresse que celle de la livraison, car la facture doit être jointe à l'envoi. Merci de me confirmer

## intent:DeliveryNews+deliveryPlace
- est ce que vous pouvez me dire à peut prêt quand il va être livré et si [Chronopost](transporter) le met dans la boîte aux lettre en cas d'ansence   car je pars [vendredi](date) et je reviens [dimanche](date)   [00](order)   vous pouvez me dire ?8   rassurez moi vous trouvez bien ma commande ?
- mais il devait m'être déjà livrer à mon [domicile](place)
- la livraison se fait en point relais ou à domicile ? 
- est ce que vous pouvez me dire à peut prêt quand il va être livré et si [Chronopost](transporter) le met dans la boîte aux lettre en cas d'ansence   car je pars [vendredi](date) et je reviens [dimanche](date)   [00](order)   vous pouvez me dire ?8   rassurez moi vous trouvez bien ma commande ?
- mais il devait m'être déjà livrer à mon [domicile](place)
- la livraison se fait en point relais ou à domicile ? 

## intent:Oui+CustomerComplaint
- [absolument](oui)   mais, je trouve que ce n'est pas sérieux de votre part
- oui mais je suis [déçue](mood_neg)
- [absolument](oui)   mais, je trouve que ce n'est pas sérieux de votre part
- oui mais je suis [déçue](mood_neg)

## intent:DeliveryPlace
- que dois je faire aujourd'hui  [recommander](resend) ou ou attendre la livraison à mon [domicile](place) comme proposer  merci
- bonjour, je voudrai acheter un parfum ici en [France](country) mais donner comme [cadeau](present) à quelqu'un aux [Etats Unis](country), est ce possible ?
- bonjour vou livre à [domicile](place) ? 
- que dois je faire aujourd'hui  [recommander](resend) ou ou attendre la livraison à mon [domicile](place) comme proposer  merci
- bonjour, je voudrai acheter un parfum ici en [France](country) mais donner comme [cadeau](present) à quelqu'un aux [Etats Unis](country), est ce possible ?
- bonjour vou livre à [domicile](place) ? 
- en [point relais](pr) peut on choisir en comment faire
- bonjour, mon colis a atterri dans un [point relais](pr) alors que j'ai payé pour une [livraison](delivery) a [domicile](place).

## intent:Resend
- vous me la [renvoyez](resend) en urgence merci
- oui effectuez le [renvoie](resend) svp
- oui le [renvoi](resend) 
- [renvoyez](resend) la commande merci j'espère une réception avant le [2412](date).
- vous me la [renvoyez](resend) en urgence merci
- oui effectuez le [renvoie](resend) svp
- oui le [renvoi](resend) 
- [renvoyez](resend) la commande merci j'espère une réception avant le [2412](date).

## intent:AccountCreation
- je souhaite m'inscrire mais cela fait 3 fois l'on me dit que mon adresse mail et la confirmation d'adresse mail ne st pas les mêmes, or si !
- je souhaite m'inscrire mais cela fait 3 fois l'on me dit que mon adresse mail et la confirmation d'adresse mail ne st pas les mêmes, or si !

## intent:Oui
- [oui](oui). Merci
- [oui](oui)

## intent:Refund

## intent:ProductPrice

## intent:Saluer
- hey
- hello
- hi
- good morning
- good evening
- hey there

## intent:CustomerService
- peux tu vous écrire par [mail](channel) ou vous [téléphoner](channel) ? ce serait plus simple en cas de problème Ok mais ce que je désire c'est de pouvoir avoir un interlocuteur en cas de problème sous quelque forme que ce soit

## intent:ProductQuality
- bonjour, les produits sont bien des  [originaux](order)?
- bonjour, les produits sont bien des [originaux](real) ?
- bonjour bonjour les pargums sont ils des [originaux](real) svp
- bonjour _Name1_, vos parfums sont ils les [vrais](real)? ou copies ? sans vouloir vous vexer mais les prix sont juste époustouflants !
- bonjour, je suis très intéressé par les prix que vous affichez mais qui me prouve l'[origine](real) des produits ?

## intent:Returned
- [_Email1_](email)  bonjour un article de ma commande a été retourné que doit je faire maintenant, merci
- [_Email1_](email)  bonjour un article de ma commande a été retourné que doit je faire maintenant, merci

## intent:PaymentSafe
- d'accord merci le paiement et sécuriser ?
- d'accord merci le paiement et sécuriser ?

## intent:ProductOrigin
- non, cette question : vous allez chercher vos produits à travers le monde etc unité à des liquidations faillites et autres ?
- oui, mis à qui les achetez vous ?
- donc votre site n'est pas en [France](place) ?
- ils partent des etats unis ? _Name1_ j'espère qu'il arrivera avant samedi matin car ensuite je part en vacances donc je ne pourrai pas le récupérer.

## intent:DeliveryCountry
- bonjour vous livrez en [Guadeloupe](country) ?

## intent:StoreLocation+DeliveryTime
- non, quand je consulte le lien sur chrono post il est prêt chez l'expéditeur. vous ? depuis le 31/12 etc vous n'êtes pas en France ?6   une petite idée du délai ?- non, quand je consulte le lien sur chrono post il est prêt chez l'expéditeur. vous ? depuis le 31/12 etc vous n'êtes pas en France ?6   une petite idée du délai ?
## intent:DeliveryNews+DeliveryPlace
